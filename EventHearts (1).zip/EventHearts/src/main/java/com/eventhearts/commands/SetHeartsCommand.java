package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import com.eventhearts.managers.HeartManager;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SetHeartsCommand implements CommandExecutor {

    private final EventHeartsPlugin plugin;
    private final HeartManager heartManager;

    public SetHeartsCommand(EventHeartsPlugin plugin, HeartManager heartManager) {
        this.plugin = plugin;
        this.heartManager = heartManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("eventhearts.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(EventHeartsPlugin.colorize("&cUsage: /sethearts <player> <amount>"));
            return true;
        }

        @SuppressWarnings("deprecation")
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(args[0]);

        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessage("player-not-found", "{player}", args[0]));
            return true;
        }

        int amount;
        try {
            amount = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getMessage("invalid-amount",
                    "{min}", String.valueOf(heartManager.getMinHearts()),
                    "{max}", String.valueOf(heartManager.getMaxHearts())));
            return true;
        }

        if (amount < heartManager.getMinHearts() || amount > heartManager.getMaxHearts()) {
            sender.sendMessage(plugin.getMessage("invalid-amount",
                    "{min}", String.valueOf(heartManager.getMinHearts()),
                    "{max}", String.valueOf(heartManager.getMaxHearts())));
            return true;
        }

        heartManager.setHearts(target.getUniqueId(), amount);

        sender.sendMessage(plugin.getMessage("admin-set",
                "{player}", target.getName(),
                "{hearts}", String.valueOf(amount)));

        if (target.isOnline()) {
            target.getPlayer().sendMessage(plugin.getMessage("hearts-set",
                    "{hearts}", String.valueOf(amount)));
        }

        return true;
    }
}
