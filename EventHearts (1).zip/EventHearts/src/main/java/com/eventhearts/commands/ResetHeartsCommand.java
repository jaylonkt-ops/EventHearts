package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import com.eventhearts.managers.HeartManager;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ResetHeartsCommand implements CommandExecutor {

    private final EventHeartsPlugin plugin;
    private final HeartManager heartManager;

    public ResetHeartsCommand(EventHeartsPlugin plugin, HeartManager heartManager) {
        this.plugin = plugin;
        this.heartManager = heartManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("eventhearts.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(EventHeartsPlugin.colorize("&cUsage: /resethearts <player>"));
            return true;
        }

        @SuppressWarnings("deprecation")
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(args[0]);

        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessage("player-not-found", "{player}", args[0]));
            return true;
        }

        int minHearts = heartManager.getMinHearts();
        heartManager.setHearts(target.getUniqueId(), minHearts);

        sender.sendMessage(plugin.getMessage("admin-reset",
                "{player}", target.getName(),
                "{hearts}", String.valueOf(minHearts)));

        if (target.isOnline()) {
            target.getPlayer().sendMessage(plugin.getMessage("hearts-reset",
                    "{hearts}", String.valueOf(minHearts)));
        }

        return true;
    }
}
