package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class SetHeartsTabCompleter implements TabCompleter {

    private final EventHeartsPlugin plugin;

    public SetHeartsTabCompleter(EventHeartsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(partial)) {
                    completions.add(player.getName());
                }
            }
        } else if (args.length == 2) {
            int min = plugin.getConfig().getInt("min-hearts", 10);
            int max = plugin.getConfig().getInt("max-hearts", 20);
            String partial = args[1];
            for (int i = min; i <= max; i++) {
                String val = String.valueOf(i);
                if (val.startsWith(partial)) {
                    completions.add(val);
                }
            }
        }

        return completions;
    }
}
