package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class EventHeartsCommand implements CommandExecutor, TabCompleter {

    private final EventHeartsPlugin plugin;

    public EventHeartsCommand(EventHeartsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("eventhearts.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 1 || !args[0].equalsIgnoreCase("reload")) {
            sender.sendMessage(EventHeartsPlugin.colorize("&cUsage: /eventhearts reload"));
            return true;
        }

        plugin.reloadConfig();
        plugin.getDataManager().loadData();
        sender.sendMessage(plugin.getMessage("config-reloaded"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            if ("reload".startsWith(args[0].toLowerCase())) {
                completions.add("reload");
            }
        }
        return completions;
    }
}
