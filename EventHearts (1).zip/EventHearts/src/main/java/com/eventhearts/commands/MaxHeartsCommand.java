package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import com.eventhearts.managers.HeartManager;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MaxHeartsCommand implements CommandExecutor {

    private final EventHeartsPlugin plugin;
    private final HeartManager heartManager;

    public MaxHeartsCommand(EventHeartsPlugin plugin, HeartManager heartManager) {
        this.plugin = plugin;
        this.heartManager = heartManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("eventhearts.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(EventHeartsPlugin.colorize("&cUsage: /maxhearts <player>"));
            return true;
        }

        @SuppressWarnings("deprecation")
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(args[0]);

        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessage("player-not-found", "{player}", args[0]));
            return true;
        }

        int maxHearts = heartManager.getMaxHearts();

        if (heartManager.getHearts(target.getUniqueId()) >= maxHearts) {
            sender.sendMessage(plugin.getMessage("target-at-max", "{player}", target.getName()));
            return true;
        }

        heartManager.setHearts(target.getUniqueId(), maxHearts);

        sender.sendMessage(plugin.getMessage("admin-maxed",
                "{player}", target.getName(),
                "{hearts}", String.valueOf(maxHearts)));

        if (target.isOnline()) {
            target.getPlayer().sendMessage(plugin.getMessage("hearts-maxed",
                    "{hearts}", String.valueOf(maxHearts)));
        }

        return true;
    }
}
