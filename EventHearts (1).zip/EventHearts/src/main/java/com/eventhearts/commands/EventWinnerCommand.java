package com.eventhearts.commands;

import com.eventhearts.EventHeartsPlugin;
import com.eventhearts.managers.HeartManager;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class EventWinnerCommand implements CommandExecutor {

    private final EventHeartsPlugin plugin;
    private final HeartManager heartManager;

    public EventWinnerCommand(EventHeartsPlugin plugin, HeartManager heartManager) {
        this.plugin = plugin;
        this.heartManager = heartManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("eventhearts.admin")) {
            sender.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(EventHeartsPlugin.colorize("&cUsage: /eventwinner <player>"));
            return true;
        }

        @SuppressWarnings("deprecation")
        OfflinePlayer target = plugin.getServer().getOfflinePlayer(args[0]);

        if (!target.hasPlayedBefore() && !target.isOnline()) {
            sender.sendMessage(plugin.getMessage("player-not-found", "{player}", args[0]));
            return true;
        }

        boolean success = heartManager.giveHeart(target.getUniqueId());
        int newHearts = heartManager.getHearts(target.getUniqueId());

        if (!success) {
            sender.sendMessage(plugin.getMessage("target-at-max", "{player}", target.getName()));
            return true;
        }

        sender.sendMessage(plugin.getMessage("admin-gave",
                "{player}", target.getName(),
                "{hearts}", String.valueOf(newHearts)));

        // Notify online player
        if (target.isOnline()) {
            target.getPlayer().sendMessage(plugin.getMessage("hearts-gained",
                    "{hearts}", String.valueOf(newHearts)));
        }

        return true;
    }
}
