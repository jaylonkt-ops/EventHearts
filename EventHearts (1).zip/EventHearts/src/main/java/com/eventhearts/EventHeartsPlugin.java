package com.eventhearts;

import com.eventhearts.commands.*;
import com.eventhearts.listeners.PlayerListener;
import com.eventhearts.managers.DataManager;
import com.eventhearts.managers.HeartManager;
import org.bukkit.plugin.java.JavaPlugin;

public class EventHeartsPlugin extends JavaPlugin {

    private static EventHeartsPlugin instance;
    private DataManager dataManager;
    private HeartManager heartManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default config
        saveDefaultConfig();

        // Initialize managers
        dataManager = new DataManager(this);
        dataManager.loadData();

        heartManager = new HeartManager(this, dataManager);

        // Register commands
        getCommand("eventwinner").setExecutor(new EventWinnerCommand(this, heartManager));
        getCommand("eventwinner").setTabCompleter(new PlayerTabCompleter());

        getCommand("eventlose").setExecutor(new EventLoseCommand(this, heartManager));
        getCommand("eventlose").setTabCompleter(new PlayerTabCompleter());

        getCommand("sethearts").setExecutor(new SetHeartsCommand(this, heartManager));
        getCommand("sethearts").setTabCompleter(new SetHeartsTabCompleter(this));

        getCommand("resethearts").setExecutor(new ResetHeartsCommand(this, heartManager));
        getCommand("resethearts").setTabCompleter(new PlayerTabCompleter());

        getCommand("maxhearts").setExecutor(new MaxHeartsCommand(this, heartManager));
        getCommand("maxhearts").setTabCompleter(new PlayerTabCompleter());

        getCommand("eventhearts").setExecutor(new EventHeartsCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this, heartManager), this);

        getLogger().info("EventHearts enabled successfully!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) {
            dataManager.saveData();
        }
        getLogger().info("EventHearts disabled. Data saved.");
    }

    public static EventHeartsPlugin getInstance() {
        return instance;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public HeartManager getHeartManager() {
        return heartManager;
    }

    public String getMessage(String key) {
        String prefix = colorize(getConfig().getString("messages.prefix", "&c[EventHearts] &r"));
        String msg = getConfig().getString("messages." + key, "&cMessage not found: " + key);
        return prefix + colorize(msg);
    }

    public String getMessage(String key, String... replacements) {
        String msg = getMessage(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }

    public static String colorize(String text) {
        return text.replace("&", "\u00A7");
    }
}
