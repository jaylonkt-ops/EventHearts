package com.eventhearts.listeners;

import com.eventhearts.EventHeartsPlugin;
import com.eventhearts.managers.HeartManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PlayerListener implements Listener {

    private final EventHeartsPlugin plugin;
    private final HeartManager heartManager;

    public PlayerListener(EventHeartsPlugin plugin, HeartManager heartManager) {
        this.plugin = plugin;
        this.heartManager = heartManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        heartManager.onPlayerJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        String message = heartManager.onPlayerDeath(event.getEntity());
        if (message != null) {
            // Send death message on respawn via scheduler
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (event.getEntity().isOnline()) {
                    event.getEntity().sendMessage(message);
                }
            }, 20L);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        // Re-apply max health on respawn (Bukkit resets health on respawn)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (event.getPlayer().isOnline()) {
                int hearts = heartManager.getHearts(event.getPlayer().getUniqueId());
                heartManager.applyMaxHealth(event.getPlayer(), hearts);
            }
        }, 1L);
    }
}
