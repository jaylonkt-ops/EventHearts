package com.eventhearts.managers;

import com.eventhearts.EventHeartsPlugin;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;

import java.util.UUID;

public class HeartManager {

    private final EventHeartsPlugin plugin;
    private final DataManager dataManager;

    public HeartManager(EventHeartsPlugin plugin, DataManager dataManager) {
        this.plugin = plugin;
        this.dataManager = dataManager;
    }

    public int getMinHearts() {
        return plugin.getConfig().getInt("min-hearts", 10);
    }

    public int getMaxHearts() {
        return plugin.getConfig().getInt("max-hearts", 20);
    }

    public int getHearts(UUID uuid) {
        return dataManager.getHearts(uuid);
    }

    /**
     * Sets hearts for a UUID (works for offline players too).
     * Clamps to configured min/max.
     * If online, applies max health immediately.
     */
    public void setHearts(UUID uuid, int hearts) {
        int clamped = Math.max(getMinHearts(), Math.min(getMaxHearts(), hearts));
        dataManager.setHearts(uuid, clamped);

        // Apply immediately if online
        Player online = plugin.getServer().getPlayer(uuid);
        if (online != null) {
            applyMaxHealth(online, clamped);
        }
    }

    /**
     * Give 1 heart. Returns false if already at max.
     */
    public boolean giveHeart(UUID uuid) {
        int current = getHearts(uuid);
        if (current >= getMaxHearts()) return false;
        setHearts(uuid, current + 1);
        return true;
    }

    /**
     * Remove 1 heart. Returns false if already at min.
     */
    public boolean removeHeart(UUID uuid) {
        int current = getHearts(uuid);
        if (current <= getMinHearts()) return false;
        setHearts(uuid, current - 1);
        return true;
    }

    /**
     * Applies the correct max health to an online player based on stored hearts.
     */
    public void applyMaxHealth(Player player, int hearts) {
        AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
        if (attr == null) return;

        double newMaxHealth = hearts * 2.0;
        attr.setBaseValue(newMaxHealth);

        // If current health exceeds new max, cap it
        if (player.getHealth() > newMaxHealth) {
            player.setHealth(newMaxHealth);
        }
    }

    /**
     * Called when a player joins — restore their max health from stored data.
     */
    public void onPlayerJoin(Player player) {
        int hearts = getHearts(player.getUniqueId());

        // If no data stored yet, initialize with min-hearts
        if (!dataManager.hasData(player.getUniqueId())) {
            dataManager.setHearts(player.getUniqueId(), getMinHearts());
            hearts = getMinHearts();
        }

        applyMaxHealth(player, hearts);
    }

    /**
     * Called on player death. Removes 1 heart if death-heart-loss is enabled.
     * Returns the message to send, or null if loss is disabled.
     */
    public String onPlayerDeath(Player player) {
        if (!plugin.getConfig().getBoolean("death-heart-loss", true)) {
            return null;
        }

        int current = getHearts(player.getUniqueId());
        if (current <= getMinHearts()) {
            return plugin.getMessage("death-at-min");
        }

        removeHeart(player.getUniqueId());
        int newHearts = getHearts(player.getUniqueId());
        return plugin.getMessage("death-lost-heart", "{hearts}", String.valueOf(newHearts));
    }
}
