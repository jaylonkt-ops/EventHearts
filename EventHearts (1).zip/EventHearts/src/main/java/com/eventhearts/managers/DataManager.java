package com.eventhearts.managers;

import com.eventhearts.EventHeartsPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataManager {

    private final EventHeartsPlugin plugin;
    private File dataFile;
    private FileConfiguration dataConfig;
    private final Map<UUID, Integer> heartsData = new HashMap<>();

    public DataManager(EventHeartsPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadData() {
        dataFile = new File(plugin.getDataFolder(), "hearts.yml");

        if (!dataFile.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                dataFile.createNewFile();
                plugin.getLogger().info("Created hearts.yml data file.");
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create hearts.yml: " + e.getMessage());
            }
        }

        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        heartsData.clear();

        if (dataConfig.contains("hearts")) {
            for (String uuidStr : dataConfig.getConfigurationSection("hearts").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    int hearts = dataConfig.getInt("hearts." + uuidStr, 10);
                    heartsData.put(uuid, hearts);
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Invalid UUID in hearts.yml: " + uuidStr);
                }
            }
        }

        plugin.getLogger().info("Loaded heart data for " + heartsData.size() + " players.");
    }

    public void saveData() {
        if (dataConfig == null || dataFile == null) return;

        for (Map.Entry<UUID, Integer> entry : heartsData.entrySet()) {
            dataConfig.set("hearts." + entry.getKey().toString(), entry.getValue());
        }

        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save hearts.yml: " + e.getMessage());
        }
    }

    public int getHearts(UUID uuid) {
        return heartsData.getOrDefault(uuid, plugin.getConfig().getInt("min-hearts", 10));
    }

    public void setHearts(UUID uuid, int hearts) {
        heartsData.put(uuid, hearts);
        saveData();
    }

    public boolean hasData(UUID uuid) {
        return heartsData.containsKey(uuid);
    }

    public Map<UUID, Integer> getAllData() {
        return new HashMap<>(heartsData);
    }
}
